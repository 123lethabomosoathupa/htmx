from django.contrib import admin
from contacts.models import User, Contact



admin.site.register(User)
admin.site.register(Contact)